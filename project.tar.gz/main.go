package main

import "elegance-gateway/controller/handler"

func main() {
	handler.InitHandler()

}
