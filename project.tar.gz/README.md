# elegance-gateway
# docker镜像

{ "registry-mirrors": [ "https://docker.211678.top", "https://docker.1panel.live", "https://hub.rat.dev", "https://docker.m.daocloud.io", "https://do.nark.eu.org", "https://dockerpull.com", "https://dockerproxy.cn", "https://docker.awsl9527.cn" ] }