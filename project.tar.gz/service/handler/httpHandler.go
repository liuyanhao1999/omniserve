package handler

import (
	http2 "elegance-gateway/service/http"
)

func RunHttp() {

	http2.InitServer()

}
